import React from 'react';

export const Deploy = ({prop}) => {
    return(<div>{prop.tutorial}</div>)
}