N-gram Language Modeling for the One Billion Word Benchmark
Overview
This project implements n-gram language models (unigram, bigram, and trigram) using Maximum Likelihood Estimation (MLE). It also incorporates linear interpolation smoothing to improve model performance. The model is evaluated using perplexity as the performance metric. The implementation includes handling out-of-vocabulary (OOV) words by replacing low-frequency tokens with a special <UNK> token.

Project Structure
run.py: The main script containing the implementation of n-gram language models and all experiments. It includes:

Data preprocessing, including OOV handling and tokenization.
Training of n-gram models using MLE.
Linear interpolation smoothing.
Perplexity calculation for train, development, and test datasets.
Experimental setups for evaluating different lambda combinations, reducing training data, and examining the effect of <UNK> replacement thresholds.
data/: A directory containing the dataset files:

1b_benchmark.train.tokens: Training data.
1b_benchmark.dev.tokens: Development data for hyperparameter tuning.
1b_benchmark.test.tokens: Test data for final evaluation.
README.md: Instructions to run the project.

Requirements
Python 3.x
Standard Python libraries (no external NLP libraries are used):
os, sys, math, argparse, collections
How to Run
Place the dataset files (1b_benchmark.train.tokens, 1b_benchmark.dev.tokens, 1b_benchmark.test.tokens) inside the data/ directory.
Run the script run.py from the terminal using the following command:
bash
Copy code
python run.py
Experiments
The run.py script conducts the following experiments:

1. Perplexity for Different Lambda Values
The script evaluates the perplexity scores on the training and development datasets for 5 different combinations of smoothing weights (λ1, λ2, λ3):

(0.1, 0.3, 0.6)
(0.3, 0.3, 0.4)
(0.4, 0.3, 0.3)
(0.2, 0.4, 0.4)
(0.5, 0.3, 0.2)
Example output:

bash
Copy code
Lambdas (0.1, 0.3, 0.6) - Train Perplexity: 29.19, Dev Perplexity: 11419.58
Lambdas (0.3, 0.3, 0.4) - Train Perplexity: 40.76, Dev Perplexity: 10932.65
...
2. Test Set Perplexity
Using the best lambda combination (selected based on development perplexity), the script evaluates perplexity on the test dataset.

Example output:

bash
Copy code
Test Perplexity with best lambdas (0.3, 0.3, 0.4): 10794.57
3. Effect of Training Data Size
The script evaluates how reducing the training data to half impacts development perplexity.

Example output:

bash
Copy code
Dev Perplexity with half training data: 3764.04
4. Impact of <UNK> Replacement Thresholds
The script evaluates how different <UNK> thresholds (e.g., 5 and 1) affect development perplexity.

Example output:

bash
Copy code
Threshold 5 - Dev Perplexity: 10932.65
Threshold 1 - Dev Perplexity: 10932.65
Debugging
To validate the implementation, the script uses a predefined sentence HDTV . and computes perplexity with specific lambda values (λ1=0.1, λ2=0.3, λ3=0.6). The expected output is:

Unigram Perplexity: 658
Bigram Perplexity: 63.7
Trigram Perplexity: 39.5
Smoothed Perplexity: 48.1
Outputs
The script outputs perplexity scores for train, development, and test datasets directly to the terminal.
Notes
Always use the development dataset for hyperparameter tuning.
Avoid evaluating on the test dataset multiple times to prevent overfitting.
Ensure the dataset files are correctly placed in the data/ directory.
Contact
For any issues or questions, please contact:

Name: Siddharth Suresh
Email: ssures23@ucsc.edu
