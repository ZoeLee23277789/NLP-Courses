import math
from collections import defaultdict, Counter


class NGramLanguageModel:
    def __init__(self, n):
        self.n = n
        self.vocab = set()
        self.ngram_counts = defaultdict(Counter)
        self.context_counts = Counter()
        self.vocab_size = 0
        self.word_counts = Counter()

    def preprocess(self, sentences, min_freq=1):
        """
        Preprocess the sentences: replace low-frequency tokens with <UNK> and add special tokens.
        """
        # Count token frequencies
        for sentence in sentences:
            for token in sentence:
                self.word_counts[token] += 1

        # Replace low-frequency tokens with <UNK>
        processed_sentences = []
        for sentence in sentences:
            processed_sentence = ["<START>"] * (self.n - 1) + [
                token if self.word_counts[token] >= min_freq else "<UNK>" for token in sentence
            ] + ["<STOP>"]
            processed_sentences.append(processed_sentence)

        # Update vocabulary
        self.vocab = set(token for sentence in processed_sentences for token in sentence)
        self.vocab_size = len(self.vocab)
        return processed_sentences

    def train(self, sentences):
        """
        Train the n-gram model using MLE.
        """
        for sentence in sentences:
            for i in range(len(sentence) - self.n + 1):
                ngram = tuple(sentence[i: i + self.n])
                context = ngram[:-1]
                token = ngram[-1]

                self.ngram_counts[context][token] += 1
                self.context_counts[context] += 1

    def ngram_probability(self, context, token):
        """
        Compute the probability of a token given a context.
        """
        if self.vocab_size == 0:
            raise ValueError("Vocabulary size is zero. Did you forget to preprocess the data?")
        context_count = self.context_counts[context]
        token_count = self.ngram_counts[context][token]
        if context_count == 0:
            return 1 / self.vocab_size
        return token_count / context_count

    def perplexity(self, sentences):
        """
        Compute the perplexity of a set of sentences.
        """
        total_log_prob = 0
        total_tokens = 0
        for sentence in sentences:
            sentence = ["<START>"] * (self.n - 1) + sentence + ["<STOP>"]
            total_tokens += len(sentence) - (self.n - 1)

            for i in range(len(sentence) - self.n + 1):
                ngram = tuple(sentence[i: i + self.n])
                context = ngram[:-1]
                token = ngram[-1]
                prob = self.ngram_probability(context, token)
                total_log_prob += math.log(prob, 2)

        return math.pow(2, -total_log_prob / total_tokens)


class SmoothedNGramLanguageModel(NGramLanguageModel):
    def __init__(self, n):
        super().__init__(n)
        self.lambdas = [1 / n] * n  # Initialize equal weights for lambdas

    def set_lambdas(self, lambdas):
        """
        Set the lambda values for linear interpolation smoothing.
        """
        if len(lambdas) != self.n or not math.isclose(sum(lambdas), 1.0):
            raise ValueError("Lambdas must have length n and sum to 1.")
        self.lambdas = lambdas

    def smoothed_ngram_probability(self, context, token):
        """
        Compute the smoothed probability of a token given a context.
        """
        probs = [self.ngram_probability(context[-i:], token) if len(context) >= i else 1 / self.vocab_size for i in range(1, self.n + 1)]
        return sum(l * p for l, p in zip(self.lambdas, probs))

    def smoothed_perplexity(self, sentences):
        """
        Compute the perplexity of a set of sentences using the smoothed model.
        """
        total_log_prob = 0
        total_tokens = 0
        for sentence in sentences:
            sentence = ["<START>"] * (self.n - 1) + sentence + ["<STOP>"]
            total_tokens += len(sentence) - (self.n - 1)

            for i in range(len(sentence) - self.n + 1):
                ngram = tuple(sentence[i: i + self.n])
                context = ngram[:-1]
                token = ngram[-1]
                prob = self.smoothed_ngram_probability(context, token)
                total_log_prob += math.log(prob, 2)

        return math.pow(2, -total_log_prob / total_tokens)


# Load and preprocess data
def load_data(file_path):
    with open(file_path, 'r') as f:
        return [line.strip().split() for line in f]


# Main experiments
def run_experiments(train_data, dev_data, test_data):
    n = 3  # Trigram model
    model = SmoothedNGramLanguageModel(n)

    # Preprocess the data
    processed_train_data = model.preprocess(train_data)
    processed_dev_data = model.preprocess(dev_data)
    processed_test_data = model.preprocess(test_data)

    # Train the model
    model.train(processed_train_data)

    # Lambda sets for experiments
    lambda_sets = [
        (0.1, 0.3, 0.6),
        (0.3, 0.3, 0.4),
        (0.4, 0.3, 0.3),
        (0.2, 0.4, 0.4),
        (0.5, 0.3, 0.2)
    ]

    # Experiment 1: Perplexity for various lambdas
    print("Perplexity scores for different lambda values:")
    for lambdas in lambda_sets:
        model.set_lambdas(lambdas)
        train_perplexity = model.smoothed_perplexity(processed_train_data)
        dev_perplexity = model.smoothed_perplexity(processed_dev_data)
        print(f"Lambdas {lambdas} - Train Perplexity: {train_perplexity:.2f}, Dev Perplexity: {dev_perplexity:.2f}")

    # Experiment 2: Best hyperparameters on test set
    best_lambdas = (0.3, 0.3, 0.4)
    model.set_lambdas(best_lambdas)
    test_perplexity = model.smoothed_perplexity(processed_test_data)
    print(f"\nTest Perplexity with best lambdas {best_lambdas}: {test_perplexity:.2f}")

    # Experiment 3: Half training data
    half_train_data = processed_train_data[:len(processed_train_data) // 2]
    model_half = SmoothedNGramLanguageModel(n)
    processed_half_train_data = model_half.preprocess(half_train_data)
    model_half.train(processed_half_train_data)
    model_half.set_lambdas(best_lambdas)
    half_train_dev_perplexity = model_half.smoothed_perplexity(processed_dev_data)
    print(f"\nDev Perplexity with half training data: {half_train_dev_perplexity:.2f}")

    # Experiment 4: <UNK> replacement
    print("\n<UNK> Replacement Impact:")
    for threshold in [5, 1]:
        model_unk = SmoothedNGramLanguageModel(n)
        processed_train_data_unk = model_unk.preprocess(train_data, min_freq=threshold)
        processed_dev_data_unk = model_unk.preprocess(dev_data, min_freq=threshold)
        model_unk.train(processed_train_data_unk)
        model_unk.set_lambdas(best_lambdas)
        dev_perplexity_unk = model_unk.smoothed_perplexity(processed_dev_data_unk)
        print(f"Threshold {threshold} - Dev Perplexity: {dev_perplexity_unk:.2f}")


# Load train, dev, and test data
train_data = load_data('1b_benchmark.train.tokens')
dev_data = load_data('1b_benchmark.dev.tokens')
test_data = load_data('1b_benchmark.test.tokens')

# Run experiments
run_experiments(train_data, dev_data, test_data)
